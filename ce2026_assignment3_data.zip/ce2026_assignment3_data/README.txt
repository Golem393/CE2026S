CE2026 Assignment 3 synthetic dataset

Contents:
- documents/*.md : local fictional source documents for the RAG lab
- public_dev_set.json : public dev benchmark used in the notebook

This dataset is fully synthetic and meant for reproducible classroom benchmarking.

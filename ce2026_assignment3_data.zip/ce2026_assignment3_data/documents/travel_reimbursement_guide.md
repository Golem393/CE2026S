# Travel Reimbursement Guide

This guide covers how CE students and staff should document approved academic travel. It focuses on the routine cases
that generate confusion every semester: conference registration, train tickets, local transit, shared lodging, and
currency conversion. The finance office would prefer to reject fewer claims, so the guide spells out the evidence
required for each expense type and the deadlines that determine whether a claim is treated as ordinary, late, or
exceptional.

## Before the Trip

Travel must be approved before any non-refundable purchase is made. Approval usually means an email from the faculty
budget owner plus a travel request number in the finance portal. Students should keep both because a valid receipt alone
does not prove the trip belonged to an approved budget. If the trip combines research and personal days, the traveler
should annotate that distinction before departure rather than trying to reconstruct it from memory later.

Registration fees, airfare, and long-distance rail tickets may be booked by the traveler or by the departmental office.
Whichever route is used, the final reimbursement packet still needs the itinerary, proof of payment, and the conference
or event information that explains why the travel was necessary. The office is faster when the purpose is obvious from
the first page.

## Required Documents and Deadlines

A complete claim normally includes the reimbursement form, proof of prior approval, itemized receipts, and a short trip
summary if the budget is research-related. Claims should be submitted within 20 calendar days after the traveler returns.
Claims submitted after 20 days are considered late and may be moved to a lower-priority review queue. Claims that arrive
after 60 days need a written exception note from the faculty budget owner.

Receipts must show vendor name, date, amount, and payment confirmation. Credit-card slips without itemization are not
enough for lodging or meals. Digital receipts are fine if they are legible. When a conference platform emails only a
summary page, save that page as a PDF immediately rather than assuming the portal link will remain live forever.

- Normal submission deadline: 20 calendar days after return.
- Exception note required: after 60 days.
- Keep itemized receipts, not only card slips.

## Ground Transportation and Meals

Public transit, airport rail, and standard buses are reimbursable with ordinary receipts. Taxi or ride-hail costs are
reimbursable only when they are safer, materially faster for a tight itinerary, or necessary because public transit is
not practical for the route and schedule. The claim should note which condition applied. A bare statement such as "used a
taxi" is usually not enough when a rail line served the same airport.

Per diem rules apply only when the trip budget explicitly allows them. Otherwise meals are reimbursed by itemized receipt
up to the budget cap. Alcohol, mini-bar purchases, and personal snacks beyond the stated policy are never reimbursable.
If several travelers share a meal, the claimant should list the attendees and mark only the reimbursable portion.

| Expense | Reimbursable? | Notes |
|---|---|---|
| Airport rail | Yes | Keep receipt or ticket confirmation |
| Taxi / ride-hail | Conditional | Explain safety, timing, or no-practical-transit reason |
| Meals with per diem budget | Usually use per diem | Do not double claim receipts |
| Alcohol | No | Excluded from reimbursement |

## Foreign Currency and Shared Lodging

For foreign expenses, claim the amount in the original currency and let the finance office convert it using the card
statement rate when available or the official daily rate when it is not. Travelers should avoid manually converting and
rounding every line because those homemade tables often create more work than they save. If a fee was paid through a
conference portal that charged in local currency, keep the portal receipt as well as the card statement.

Shared lodging is reimbursable only for the claimant's portion. If one traveler paid the full hotel bill, the claim
packet should include the hotel folio plus a note showing how the cost was split. Do not submit the entire folio on two
separate claims. The office sees that duplicate pattern regularly and treats it as a preventable delay, not a harmless
administrative accident.

## Common Reasons for Delay

Most delayed claims involve one of five issues:
1. Missing prior approval reference.
2. Card slips without itemized receipts.
3. Taxi claims with no justification.
4. Submission after the 20-day window.
5. Shared lodging split not explained.

Students can avoid almost all of these by assembling the packet during the trip rather than after returning to classes.

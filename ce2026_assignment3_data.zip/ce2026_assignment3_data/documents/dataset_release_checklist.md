# Dataset Release Checklist

This checklist is used when a CE project wants to publish, share, or archive a dataset outside the immediate project
team. The document covers public releases, restricted collaborator handoffs, and instructor-provided classroom datasets.
It does not attempt to replace legal review, but it does specify the minimum evidence the data steward must collect
before the dataset moves from internal storage into any wider distribution channel. The checklist is intentionally a mix
of policy and workflow because release mistakes usually come from skipped steps rather than misunderstood principles.

## Release Categories

The lab distinguishes between three release categories. A public release is accessible to anyone and therefore requires
the strongest review. A partner release is shared only with named collaborators under an agreement. A classroom release
is distributed to enrolled students and teaching staff for instructional purposes. The release category determines how
strictly the steward must document identity risk, licensing, and embargo status.

Public releases need both a privacy review and a licensing review. Partner releases still need a privacy review, but the
licensing step may be narrower if the underlying agreement already specifies permitted uses. Classroom releases are often
treated as internal from an access-control perspective, yet they still need a short privacy screening if they contain
human-generated text, logs, or media. The lab uses the same front-page checklist so teams do not accidentally assume a
classroom release is exempt from review.

## Mandatory Reviews

Before any dataset leaves the project drive, the data steward must complete a privacy review. For datasets with human
subjects, free-text fields, transcripts, support tickets, or device logs that can be tied back to individuals, the
steward must also obtain written sign-off from the faculty data owner and the privacy officer. These are the two most
important approvals on the entire form. If either one is missing, the release is blocked even when the technical files
look clean.

Licensing review asks a different question: do all source materials allow redistribution under the intended release
terms? If a dataset mixes internally collected data with external benchmarks, the steward must verify that the external
licenses allow onward distribution. If redistribution is not allowed, the release package must replace the restricted
portion with download instructions, hashes, or scripts rather than the raw files themselves.

- Public human-subjects release: faculty data owner + privacy officer sign-off required.
- Public non-human-source release: licensing review still required.
- Partner release: use agreement ID and recipient list.

## Technical Packaging

Every release package must include a dataset card, a manifest, and integrity metadata. The dataset card should explain
collection scope, intended use, known failure modes, and fields removed during de-identification. The manifest should
list every file with byte size and checksum. The checksum algorithm used by the CE lab is SHA-256 because it is widely
supported in both teaching and production environments. Teams sometimes prefer shorter hashes for slides, but the release
record in the archive should still store the full SHA-256 value.

The package should also contain a version note using the form `major.minor.patch`, where patch increments mean metadata
fixes, minor increments mean new examples or corrected annotations, and major increments mean structural changes that may
break downstream scripts. Do not rename columns casually between minor versions. Release consumers often remember file
names better than dataset card details, so stability matters.

| Artifact | Required for public release | Notes |
|---|---|---|
| Dataset card | Yes | Plain-language summary plus caveats |
| File manifest | Yes | Include SHA-256 checksums |
| README with loading example | Yes | Prefer one short reproducible example |
| Agreement ID list | Partner only | Needed for restricted handoff |

## Embargoes and Timing

Projects tied to an active paper submission, patent review, sponsor report, or competition deadline may require an
embargo even after the files pass privacy and licensing review. The steward should record the embargo reason, the end
date, and the person authorized to lift it. Embargoes are common for summer projects because teams want to freeze the
data package early while delaying the public link until the corresponding manuscript is visible.

The checklist also asks whether the dataset contains credentials, internal URLs, or operational notes that would be safe
inside the project but inappropriate in a public repository. These issues are not classic privacy failures, yet they can
still create security problems or confuse downstream users. Treat the README as part of the release surface, not just
the data files themselves.

## Release Decision Notes

The final section records who approved the release, where the package will live, and what should happen if a later
problem is discovered. If a post-release issue is found, the steward must freeze the download link, notify recipients,
and open an incident ticket if the issue involves unintended disclosure. Minor metadata fixes do not require a full
incident, but they still need a versioned correction note.

Common mistakes:
1. Forgetting privacy officer sign-off for transcript-like data.
2. Shipping only short hashes instead of full SHA-256 checksums.
3. Assuming classroom distribution never needs privacy review.
4. Copying restricted benchmark files into a public package.
5. Ignoring operational notes embedded in README examples.

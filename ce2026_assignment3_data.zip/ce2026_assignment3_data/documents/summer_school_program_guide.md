# Summer School Program Guide

This guide introduces the CE summer school for incoming students, external visitors, and teaching assistants. It is a
program document rather than a pure policy memo, but it still contains logistical rules that intersect with travel,
guest handling, and classroom access. Students often skim only the schedule page, so the guide repeats the most important
operational expectations in several places. The aim is to help participants plan their week without needing a separate
email thread for every small question.

## Program Structure

The summer school runs for five instructional days followed by a half-day poster showcase. Mornings are reserved for
lectures, afternoons for labs, and late afternoons for project studio time. Each participant joins one small team for a
mini-capstone built around synthetic operational data rather than live campus systems. The program intentionally mixes
theory and implementation so students can compare design decisions across teams.

Attendance matters because the labs build on one another. Participants who miss a morning lecture are still welcome at
the afternoon lab, but they may need to review the shared notes before the hands-on portion begins. Teaching assistants
hold a short recap at 13:15 for that purpose. The showcase on Friday ends by 15:30 so that travelers can reach evening
trains without leaving mid-session.

## Participant Support and Stipends

External participants receive a fixed travel stipend rather than item-by-item reimbursement through the summer school
budget. The stipend is released after on-site check-in and final attendance confirmation. Local participants do not
receive the travel stipend, but they may use the standard travel reimbursement process for separately approved program
expenses. This distinction matters because participants sometimes try to combine the stipend with ordinary taxi claims.

Meals during the official program window are provided on site, except dinner on the free evening. Accessibility requests,
dietary needs, and quiet-study space requests should be sent to the program office at least one week before arrival. The
office can often help later than that, but one week is the stated planning window.

## Lab Sessions and Facility Rules

Participants use the teaching side of the CE suite during scheduled labs. They do not receive independent after-hours
badge access as part of the summer school. Optional evening study sessions may be held, but those happen in the seminar
room and require staff presence. Guests, including family members, are not allowed in the lab sessions unless the office
has registered them for the Friday showcase as visitors.

Poster printing support is available until Thursday 17:00. Teams that miss that deadline may still present digitally, but
they should not expect same-night staff help. For lab computing, the program uses shared teaching accounts and a fixed
software image so that participants spend time on the exercise rather than on environment setup. Personal laptops are
allowed for note-taking and local coding, but graded lab outputs must still be submitted through the program platform.

## Showcase Day

The Friday showcase includes poster viewing, short demos, and a closing discussion. Registered visitors may enter the
showcase space from 13:00 to 15:30. The event is designed as a public-facing academic activity, so photography is
generally allowed in the showcase area unless a poster is marked no-photo. Visitors may not roam into the lab workrooms
or storage areas without a host because the public event designation applies only to the showcase zone.

Teams should prepare a compact explanation of their pipeline choices, including how they balanced quality, cost, and
operational simplicity. This recurring emphasis on trade-offs is deliberate: the program wants participants to explain
why a cheaper or more transparent solution can be preferable even when a heavier system performs slightly better.

The showcase is also the only point in the week when casual visitors can see participant work without a separate host-led
tour request. That is why the guide repeats the boundary between showcase space and lab workrooms so often. The program
office would rather sound repetitive than deal with awkward misunderstandings at the doorway.

## Practical Notes

Useful reminders:
- Poster printing support ends Thursday at 17:00.
- Friday showcase visitor window is 13:00-15:30.
- Travel stipend is fixed for external participants and released after check-in plus attendance confirmation.
- Summer school participants do not receive independent after-hours badge access.
- Graded lab outputs go through the program platform, not ad hoc email attachments.

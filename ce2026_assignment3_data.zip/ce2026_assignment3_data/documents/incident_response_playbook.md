# Incident Response Playbook

This playbook is the lab's first-response guide for safety incidents, security concerns, data exposure events, and major
equipment faults. It is designed for the first 30 minutes of confusion, when people need a simple sequence of actions
more than a perfect long-form report. The playbook aligns with campus policy but uses CE-specific roles, room names, and
communication channels so that staff and students can act quickly without translating general guidance into local terms.

## Severity Levels

Incidents are grouped into four severity levels. Severity 1 covers minor disruptions such as a short workstation outage
with no safety impact. Severity 2 covers equipment faults, suspicious access activity, or localized spills that require
staff response but do not threaten building-wide safety. Severity 3 covers events with meaningful injury risk, sensitive
data exposure, or loss of a critical shared service. Severity 4 covers life safety threats, uncontrolled chemical
release, fire, or any event requiring immediate campus emergency services.

Classifying severity is useful because it determines who must be paged first and how fast containment should begin. Staff
do not need perfect certainty before acting. If you are unsure between two levels, start with the higher one and let the
on-call lead downgrade it later after more information arrives.

## Immediate Actions

The first responder should secure people before equipment. For medical emergencies, fire, or uncontrolled release,
contact campus emergency services immediately, then evacuate or isolate the area as directed. For non-life-threatening
events, stop active work, preserve the scene, and notify the appropriate lead. Guests should be moved to the seminar room
or corridor muster point and should not participate in cleanup or technical triage.

Containment targets:
1. Severity 2: begin containment within 15 minutes.
2. Severity 3: begin containment within 10 minutes and notify the on-call lead immediately.
3. Severity 4: call emergency services first; containment follows emergency instructions.

These targets are not abstract service goals. They exist because the lab has learned that seemingly small delays make
later evidence collection and safety review much harder.

## Notifications and Logging

For Severity 1 or 2, notify the lab manager and create an incident ticket before the end of the same shift. For
Severity 3, page the on-call lead immediately and notify the lab manager, faculty area owner, and security contact as
soon as the scene is stable. For Severity 4, emergency services and campus security come first; internal notifications
follow once people are protected.

The incident log should record time, location, people present, immediate actions, and any guest names who were on site
during the event. If a digital system is involved, record affected hostnames, account names, and whether the system was
isolated from the network. Do not overwrite logs or restart a suspicious machine unless the playbook explicitly requires
containment by shutdown.

| Severity | First notification | Log deadline |
|---|---|---|
| 1 | Lab manager | End of same shift |
| 2 | Lab manager | End of same shift |
| 3 | On-call lead immediately | Initial ticket as soon as stable |
| 4 | Emergency services first | Internal log after emergency response starts |

## Evidence Preservation

Preserve evidence in place whenever it is safe to do so. Photograph equipment state, screen messages, or spill boundaries
before cleanup if that can be done without delaying safety actions. For possible data exposure, copy relevant logs to the
incident folder and restrict access rather than forwarding them widely by email. For hardware faults, label the device as
do-not-use and keep accessories together so later inspection can reconstruct the context.

The playbook specifically warns against well-meaning cleanup that destroys context. Rebooting a workstation, deleting
temporary files, or re-running a failed script may feel helpful, but it often makes the incident harder to diagnose. If a
system must be disconnected, document exactly what was unplugged or disabled.

## Follow-Up Review

After the first response, the lab manager assigns an owner for the corrective-action note. Severity 1 notes may be
closed with a short operational fix. Severity 2 and 3 require a brief review meeting within five business days. Severity
4 follows campus emergency review rules in addition to the local meeting. The corrective-action note should identify what
will change, who owns the change, and when the team will verify that it happened.

Common reminders:
- If unsure, classify higher first.
- Guests never assist with spill cleanup or incident triage.
- Severity 3 requires immediate paging of the on-call lead.
- Preserve logs and physical context whenever safe.
- Begin Severity 2 containment within 15 minutes.

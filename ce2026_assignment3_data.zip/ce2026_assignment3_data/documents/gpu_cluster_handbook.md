# GPU Cluster Handbook

The CE GPU cluster supports coursework, small-scale experiments, and shared research workloads. The handbook explains
how researchers should prepare jobs, pick a queue, manage scratch storage, and handle failures without overloading the
cluster support team. Many users only read the login section, but the most expensive mistakes typically come from queue
selection and storage cleanup, so those sections are deliberately detailed. The handbook assumes a mixed community of
students and staff who share the same hardware but not always the same urgency.

## Accounts, Login, and Quotas

Access starts with a project account and a linked campus identity. New accounts are normally created within one business
day after the faculty sponsor confirms the project code. Users should log in through the gateway node with SSH keys;
password-only logins are disabled except during account recovery. Each person receives a home directory for scripts and
small artifacts, a project space for shared checkpoints, and a scratch area for temporary training outputs.

Home directories are backed up nightly but limited to 20 GB. Project spaces are backed up weekly and default to 500 GB,
though larger quotas are possible for funded projects. Scratch storage is the opposite: it is fast, large, and not
backed up. Users should assume scratch data may disappear at any time after the purge window. The cluster team repeats
this warning because people still place irreplaceable notebooks and credentials in scratch folders.

- Gateway login: `ssh your_id@gateway.ce-cluster.local`
- Home quota: 20 GB, nightly backup.
- Project quota: 500 GB by default, weekly backup.
- Scratch quota: shared fast storage, no backup.

## Queues and Scheduling

The scheduler provides three ordinary queues plus two restricted queues. The `short` queue is intended for jobs under
two hours and is the right default when you are testing a training loop, checking environment compatibility, or running
a small evaluation pass. The `standard` queue is for ordinary research runs up to 24 hours. The `long` queue exists for
carefully justified experiments up to 72 hours. Instructors and cluster admins may also use `teaching-burst` during
scheduled labs and `maintenance-hold` when nodes are being drained for repairs.

Users should not game the scheduler by placing a short job into `standard` simply to avoid queue limits. The system
tracks this pattern and will lower job priority for repeated abuse. Conversely, do not put a 10-hour run into `short`
hoping it finishes quickly; the scheduler will terminate it at the two-hour mark. If a run can be split into smaller
checkpoints, the support team prefers that design because it uses shared resources more fairly.

| Queue | Typical limit | Best use |
|---|---|---|
| short | 2 hours | smoke tests, quick evals, debug runs |
| standard | 24 hours | ordinary training and inference |
| long | 72 hours | approved long experiments |
| teaching-burst | course window only | TA-managed lab sessions |

## Scratch Storage and Data Hygiene

Scratch is optimized for throughput rather than retention. Files in scratch that have not been touched for 14 days are
marked as abandoned. The nightly cleanup job then purges abandoned scratch files every Tuesday at 03:00 local time. A
file touched on Monday afternoon is safe for that week's cleanup, while an untouched file sitting for more than 14 days
will likely vanish in the next Tuesday cycle. The policy uses last-access time rather than last-modified time so that
evaluation-only pipelines do not keep dead outputs forever.

Users who need stable intermediate outputs should copy them to project storage before the purge window. Symbolic links to
scratch do not protect data. The handbook also discourages storing raw datasets on local node disks; those disks are
reimaged whenever a node fails validation. If a project depends on a large frozen dataset, stage it once in project
storage and mount read-only views in jobs whenever possible.

Numbered storage checklist:
1. Write checkpoints to scratch during active training.
2. Promote final checkpoints and summaries to project space.
3. Never keep secrets or irreplaceable notebooks in scratch.
4. Review scratch age before leaving for a break or conference.
5. Expect abandoned scratch cleanup every Tuesday at 03:00.

## Node Failures and Maintenance

Most job failures are ordinary software errors, but a few patterns signal infrastructure trouble. If several jobs fail
on the same host with filesystem or GPU reset errors, capture the scheduler job IDs and report the node name. The
cluster team would rather receive one concise report with exact host information than several vague complaints about
training instability. Planned maintenance is usually announced 48 hours in advance and starts at 07:30 on the first
Wednesday of each month.

During maintenance windows, new jobs are blocked and long-running jobs may be drained early from affected nodes. Users
with deadline-sensitive work should watch the status page and avoid launching a 24-hour job right before the monthly
window. If a node crash corrupts results, the cluster team can help inspect system logs, but they cannot restore scratch
files that were never copied elsewhere.

## Support Escalation and Fair Use

Support requests should start in the `#ce-cluster-help` channel or the ticket form. Mark the ticket as urgent only for
active deadlines, repeated node failures, or account lockouts that block scheduled coursework. A single failed library
install is usually not urgent. When the cluster appears unhealthy, include the exact command, queue, job ID, and node
name so the on-call engineer can reproduce the issue quickly.

Fair-use reminders:
- Do not reserve more GPUs than the script can use.
- Release idle interactive sessions.
- Use `short` for jobs under two hours.
- Clean scratch proactively before travel or semester breaks.
- Acknowledge the cluster in course reports when required by the syllabus.

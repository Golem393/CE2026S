# Equipment Booking FAQ

This FAQ describes how shared CE equipment is reserved, modified, and returned. It is written for students who use the
booking portal only occasionally and therefore forget small but important constraints such as notice windows, turnover
buffers, and cancellation fees. The equipment office handles dozens of small requests every week, so the goal is to make
the routine rules explicit enough that staff do not need to answer the same questions over and over.

## Booking Windows

Most portable equipment may be booked up to 14 days in advance. High-demand items such as thermal cameras, lidar kits,
and the field recording backpack open on a shorter rolling window of 7 days so that one project cannot freeze the
calendar a month early. Faculty-led field courses may request a seasonal hold, but those requests are entered by staff
rather than through the student portal.

Standard bookings must be made at least 12 hours before pickup. Same-day emergency requests are sometimes approved for
teaching disruptions, but the office does not promise them. The FAQ emphasizes this because users often confuse "can be
approved" with "should be expected." If an item requires a battery conditioning cycle or calibration check, the office
may refuse a rushed request even when the calendar appears open.

- Portable equipment window: 14 days.
- High-demand equipment window: 7 days.
- Minimum lead time for ordinary bookings: 12 hours.

## Training and Eligibility

A reservation does not bypass training requirements. If an item is marked training-gated, the named pickup person must
hold the corresponding certification in the booking system by the time of pickup. Project teams sometimes reserve under
one person's name and send another person to collect the item; that fails when the second person lacks certification. If
the equipment supports only supervised use, the supervisor must also be listed on the booking record.

Certain devices also require a short pre-use briefing after long gaps. For example, if a user has not checked out the
thermal camera kit in more than 180 days, the office may ask for a five-minute refresher before release. This is not a
punishment. It is a cheap way to prevent repeat mistakes with lenses, batteries, and SD cards.

## Cancellations, Returns, and Late Fees

Bookings can be canceled without penalty until 18:00 on the business day before pickup. After that cutoff, the request
counts as a late cancellation unless the office waives the fee for illness, campus closure, or documented travel delay.
Late returns are handled separately. Portable items returned within the first two hours after the due time incur a small
warning fee; after that, the charge escalates by equipment tier because downstream reservations may be disrupted.

Overnight bookings must be returned by 10:00 on the next business day unless the portal shows a multi-day reservation.
Users should not assume that "overnight" means 24 hours. The office uses mornings for charging, inspection, and quick
repairs before the next pickup window. Any missing accessories are logged against the reservation until the office can
confirm that the part was simply packed in the wrong pouch.

| Event | Rule | Notes |
|---|---|---|
| Free cancellation | Before 18:00 previous business day | No fee |
| Late cancellation | After cutoff | Fee may be waived for documented disruption |
| Overnight return | By 10:00 next business day | Not a full 24-hour window |
| Missing accessory | Logged immediately | Closed after verification |

## Extensions and Shared Use

If you need more time, request the extension before the original due time. Extensions are approved only when the item is
not already committed to another reservation or a maintenance block. The office prefers formal extensions over informal
email chains because the portal timestamps the change and updates insurance responsibility. Shared use across lab mates
is allowed only when every user is listed on the booking and the primary user remains responsible for the full kit.

The FAQ also reminds students not to split a kit into subcomponents for convenience. Borrowing one microphone from a
field audio set and leaving the rest in a locker sounds harmless, but it breaks the inspection workflow and makes the
next checkout slower. Reserve the right kit rather than repackaging it yourself.

## Practical Tips

Practical reminders from the office:
1. Check charger type before leaving the building.
2. Photograph the packed kit only if the office asks; routine checkouts do not need it.
3. Use extension requests instead of apologetic late-return emails.
4. Return overnight items by 10:00 on the next business day.
5. Expect high-demand items to use the 7-day booking window, not the 14-day window.

# Guest Safety Memo

This memo explains how external visitors, short-term collaborators, parents, vendors, and prospective students may be
brought into the CE facilities without creating confusion about training or supervision. It is intentionally practical:
hosts often need to decide quickly whether a visit is a hallway tour, a hands-on demonstration, or a temporary work
session. The memo therefore distinguishes between simple escorted visits and situations in which a guest is expected to
touch samples, use a workstation, or remain in the lab for several hours.

## Pre-Visit Preparation

Hosts must submit the guest access form at least three business days before a first-time visit. Returning guests who
visited within the last six months need only one business day of notice unless the destination includes a restricted
room. The form asks for the guest's legal name, affiliation, citizenship for export-control screening, emergency phone
number, and a short description of planned activities. The lab office uses that information to print the guest log and
to prepare disposable PPE if the visit includes any bench area.

If the visit involves minors, the host must use the youth visitor supplement instead of the standard form. Youth visits
are limited to demonstration spaces and may not include the wet bench annex, the soldering bay, or any room where a
laser alignment is in progress. For vendors, the host should also record the service ticket number so building services
can verify why the vendor is on site.

- First-time guest form deadline: three business days.
- Returning guest form deadline: one business day in ordinary cases.
- Youth visitor supplement required for any guest under 18.

## Escort, PPE, and Conduct Rules

Guests must wear the same minimum protective gear as the space they enter, even if they only plan to observe. In the
classroom side of the CE suite that normally means closed-toe shoes and a visitor badge. In the prototyping room it also
means safety glasses. In the wet bench annex, disposable gloves and splash goggles are required, but most guests are not
allowed there at all because the host would need to provide task-specific instruction on waste handling.

Hosts should explain three conduct rules before the tour starts. First, guests should not touch instruments, samples, or
chemical containers unless the host explicitly instructs them to do so. Second, photography is allowed only in approved
zones because several projects are under unpublished review. Third, guests should stay on marked walking paths and avoid
backpacks near benches and cable trays. These rules sound simple, but nearly every previous close call involved someone
placing a bag or cup in the wrong place rather than a dramatic equipment failure.

| Zone | Minimum guest PPE | Extra restriction |
|---|---|---|
| Seminar room | Visitor badge, closed-toe shoes | No food during demonstrations |
| Prototyping room | + safety glasses | Stay behind yellow tape during live cutting |
| Observation corridor | Visitor badge | No tripods |
| Wet bench annex | Not allowed for standard guests | Use training-session procedure instead |

## Temporary Hands-On Sessions

Some visits are not pure tours. If a guest needs to handle a sample, run a short script, or inspect raw outputs on a
shared workstation, the host must classify the event as a temporary hands-on session. That change matters because the
guest must sign the short-form acknowledgement before entering and the host must remain within immediate reach of the
guest for the entire activity. Immediate reach means the host can intervene without crossing another room.

Hands-on sessions are capped at 90 minutes for ordinary guests. Longer activities require prior approval from the lab
manager because longer stays resemble temporary work rather than a visit. When a guest uses a workstation, the host must
log in with the shared guest profile or a project-specific temporary account; personal accounts and saved browser
sessions may not be exposed. If the session includes sample photography or unpublished data, the host should verify that
the confidentiality note on the sign-in sheet matches the project status.

Numbered host checklist:
1. Collect signatures before entering the work area.
2. Give a two-minute verbal safety briefing.
3. Keep the guest within immediate reach.
4. Use guest or temporary accounts only.
5. End the session at 90 minutes unless the manager approved an extension.

## Incident Handling During a Visit

If any alarm, spill, or instrument fault occurs during a visit, the host should stop the tour first and move the guest
to the seminar room or corridor muster point. The host then follows the incident response playbook. Guests should never
be asked to help clean a spill or restart equipment. If the guest is a vendor with repair responsibility, the host may
keep them nearby only after the area has been declared safe by staff. This distinction exists because technical expertise
does not replace site-specific authority during a live incident.

The host must note the guest's presence in the incident log whenever the disruption happens during the visit window,
even if the guest did not cause it. That note helps later reviewers explain why an unfamiliar name appears in door logs,
camera footage, or temporary account records. If medical attention is needed, call campus emergency services first and
only then notify the lab office.

## Special Cases and FAQs

Prospective graduate students, visiting speakers, and parents often ask whether the memo allows them to stay during an
evening demo. The answer depends on both time and activity. A standard escorted tour may continue after 18:00 only in
the approved guest zones listed in the lab access policy. Any hands-on activity after 18:00 requires the host plus a
second trained staff member, because the lab uses a two-adult rule for evening guest interactions. Overnight guest stays
are never approved.

Frequently asked questions:
- Can a returning guest skip the form? No. The notice window is shorter, but the form is still required.
- Can a guest use a personal laptop on the CE guest Wi-Fi? Yes, in approved guest zones.
- Can a guest stay for a three-hour data walkthrough? Not as a standard hands-on session; that needs manager approval.
- Can a guest enter a restricted room just to watch? No, not under the standard guest pathway.

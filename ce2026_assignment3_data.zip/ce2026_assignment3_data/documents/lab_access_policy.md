# Lab Access Policy

This policy governs routine access to the Computational Experimentation (CE) suite, the wet bench annex, the
instrument room, and the after-hours collaboration area. The policy is written for students, research assistants,
visiting scholars, and staff who share the same badge system and the same incident logging process. It should be
read together with the guest memo and the incident response playbook because badge access, escort obligations,
and emergency shutdown responsibilities overlap in practice. The intention is to keep access predictable without
slowing down normal lab work.

## Access Levels

The CE suite uses four access levels. Level A is daytime classroom access and covers the seminar room, the printer
corner, and the public equipment lockers. Level B adds supervised access to the prototyping room and the sample prep
bench. Level C adds trained-user access to the laser cutter room, soldering bay, and shared imaging station. Level D
is the after-hours operations level and is granted only to registered researchers who already hold Level B or C.

Students in a taught course normally receive Level A automatically during the semester. Project teams that need
instruments after the sixth week can request Level B if one faculty sponsor and one lab manager approve the request.
Level C always requires equipment-specific certification because the same person may be safe in the soldering bay but
not yet cleared for the imaging station. Level D never overrides training requirements; it only changes the time window
in which approved users may enter.

- Level A hours: 08:00-20:00 on teaching days.
- Level B hours: 08:00-22:00 with an active reservation when instruments are involved.
- Level C hours: 08:00-22:00 and only for listed devices.
- Level D hours: 22:00-07:00, weekends, and campus holidays.

## Badge Rules and Entry Windows

Badge holders must tap in individually. Tailgating is treated as an access violation even when the second person is a
known classmate. If the badge reader fails twice, the user should stop retrying and contact the evening desk or the
on-call manager rather than force the door. The policy is strict here because repeated failed swipes are used in the
security dashboard to detect lost badges and faulty readers.

First-time badge activation is never immediate. A normal classroom badge becomes active by the next business morning.
Requests that add Level B or Level C are processed within two business days after the training records appear in the
lab roster. Requests for Level D are batched every Thursday at 16:00 so the manager can compare the access list with
the incident log and the overnight booking calendar. Users should therefore avoid assuming that a last-minute request
will be approved before a weekend experiment.

| Area | Badge requirement | Notes |
|---|---|---|
| CE suite | Level A or above | Classroom use allowed |
| Instrument room | Level B or C | Reservation required for shared devices |
| Laser cutter room | Level C | Certification must be current |
| After-hours area | Level D | Only for registered overnight work |

## Guests, Escorts, and Restricted Areas

Guests are not issued independent door credentials for this facility. They enter under the sponsor's responsibility
and must remain within sight or direct supervision of the sponsor whenever the visit includes an active work area.
During regular daytime tours a single trained sponsor may escort up to three guests. After 18:00 the ratio tightens:
one trained sponsor may escort at most two guests, and the guests must stay inside the seminar room, observation
corridor, or collaboration area unless a second trained staff member joins the visit.

Some rooms are never available to ordinary guests. The wet bench annex, the chemical cabinet, and the laser cutter room
are restricted to credentialed users even if the visit is only observational. The imaging station may be shown to guests
only from the marked visitor line. If a host wants a guest to handle equipment, the request must be converted into a
temporary training session and follow the guest safety memo instead of the informal tour rules in this document.

Numbered checklist for a hosted visit:
1. Confirm the sponsor's badge level and current training.
2. Check whether the destination rooms are on the restricted list.
3. Log the guest names at the front desk or in the evening tablet.
4. Keep the guests with the sponsor at all times.
5. End the visit immediately if an alarm, spill, or instrument fault occurs.

## After-Hours Work and Quiet Operations

After-hours work is allowed only for tasks that genuinely need uninterrupted time, such as long instrument runs,
overnight simulations, or early-morning preparation before a scheduled field deployment. The approved user must place
an after-hours booking in the calendar before 20:00 on the same day. At least two approved users must be listed for
wet work, but a solo researcher may conduct dry computational work in the CE suite if they remain reachable by phone.

Quiet operations rules are narrower than general access rules. The fume hood, compressed gas lines, and powered cutting
equipment may not be started after 22:00, even by Level D users. The imaging station may continue running if it was
started before 22:00 and the operator remains in the suite. If a user leaves during an after-hours run, the run must be
paused or handed over to another approved operator. Doors must never be propped open to ease repeated trips.

The lab manager reviews overnight access logs every Monday. Repeated violations lead first to a warning, then to a
two-week suspension of Level D access, and finally to a full retraining requirement if the same behavior continues.

## Exceptions and Administrative Notes

Emergency repair technicians, custodial staff, and campus security officers may enter restricted rooms under separate
campus procedures. Their presence does not automatically authorize students to enter with them. When faculty bring an
external evaluator, the evaluator is still treated as a guest unless the dean's office has pre-registered the visit as
an official audit. The policy also distinguishes between access permission and booking permission: a trained user may
hold the right badge yet still be unable to use a device without a reservation.

Frequently asked questions:
- Can a student lend a badge to a teammate? No. Badge sharing is always prohibited.
- Can a Level D user bring three guests after 19:00? No. The after-18:00 escort ratio is two guests per trained sponsor.
- Does Level D allow overnight welding or cutting? No. Quiet operations rules still block powered cutting equipment.
- Can an untrained student observe from the collaboration area? Yes, if the sponsor keeps them in approved guest zones.
